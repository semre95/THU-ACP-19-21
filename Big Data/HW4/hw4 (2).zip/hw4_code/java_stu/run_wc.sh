#!/bin/bash

OUTPUTPATH="wc_res/"

echo ===== WordCount JAVA VERSION =====

echo ===== Compile =====
hadoop com.sun.tools.javac.Main WordCount.java
jar cf wc.jar WordCount*.class
echo
echo ===== Clear old output files on HDFS =====
hdfs dfs -rm -r $OUTPUTPATH
echo
echo ===== RUN =====
hadoop jar wc.jar WordCount /hw4/temp.txt $OUTPUTPATH
echo DONE!
echo You can use "hdfs dfs -get wc_res/ {your_local_path}" to get the result file
echo
