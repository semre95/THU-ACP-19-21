#!/usr/bin/python
"""reducer.py"""

import sys

for line in sys.stdin:
  #TODO
