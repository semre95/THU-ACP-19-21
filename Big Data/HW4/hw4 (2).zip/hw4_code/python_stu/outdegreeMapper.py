#!/usr/bin/python
"""mapper"""

import sys

for line in sys.stdin:
   # TODO 

